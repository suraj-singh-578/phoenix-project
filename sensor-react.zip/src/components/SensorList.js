import React, { useState } from 'react'
import './SensorList.css'

export default  () => {
    const [sensorData, setSensorData] = useState([])
    const [fromDate, setFromDate] = useState('2020-01-01')
    const [fromTime, setFromTime] = useState('12:00')
    const [toDate, setToDate] = useState('2020-01-01')
    const [toTime, setToTime] = useState('12:00')
    const [sensor, setSensor] = useState('0')

    
    let sensorDataMapped = sensorData.map(ele => <div>sample</div>)

    let table = <table className="table table-striped my-5">
        <thead>
            <tr>
                <th>Time</th>
                <th>Temperature</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Mark</td>
                <td>Otto</td>
            </tr>
            <tr>
                <td>Jacob</td>
                <td>Thornton</td>
            </tr>
        </tbody>
    </table>

    const getDataHandler = (e) => {
        console.log({
            sensor,
            fromDate,
            fromTime,
            toDate, 
            toTime,
        })
    }

    return (
        <div className='container main p-3 px-5'>
            <h1 className="text-center my-3">Real-time Temperature Monitoring System</h1>
            <div className="d-flex justify-content-center">
                <div className="row mt-3">
                    <div className="col-4 text-center">
                        <select value={sensor} onChange={ele => setSensor(ele.value)} className="custom-select">
                            <option value='0'>Please select a sensor</option>
                            <option value="1">Sensor One</option>
                            <option value="2">Sensor Two</option>
                            <option value="3">Sensor Three</option>
                        </select>
                        <button onClick={getDataHandler} className='btn btn-primary mt-3'>Submit</button>
                    </div>
                    <div className="col-8">
                        <div>
                            <span>From:</span>
                            <input value={fromDate} onChange={ele => setFromDate(ele.value)} className='m-2' type="date"  />
                            <input value={fromTime} onChange={ele => setFromTime(ele.value)} className='m-2' type="time"  />
                        </div>
                        <div>
                            <span>To:</span>
                            <input value={toDate} onChange={ele => setToDate(ele.value)} className='m-2' type="date"  />
                            <input value={toTime} onChange={ele => setToTime(ele.value)} className='m-2' type="time"  />
                        </div>
                    </div>
                </div>
            </div>


            <div className="d-flex justify-content-center">
                {table}
            </div>
        </div>
    )
}
