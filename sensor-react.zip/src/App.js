import logo from './logo.svg';
import SensorList from './components/SensorList'
import './App.css'

function App() {
  return (
    <div className="App p-5">
      <SensorList/>
    </div>
  );
}

export default App;
